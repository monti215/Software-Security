package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@SpringBootApplication
public class ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}

}

@RestController
class ServerController{
	//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
	public class ChecksumGenerator {

		public static String generateChecksum(String input) {
			try {
				MessageDigest md = MessageDigest.getInstance("SHA-256");	            
				md.update(input.getBytes());
				byte[] hashBytes = md.digest();
				String checksum = bytesToHex(hashBytes);

				return checksum;
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
				return null;
			}
		}

		private static String bytesToHex(byte[] bytes) {
			StringBuilder result = new StringBuilder();
			for (byte b : bytes) {
				result.append(String.format("%02X", b));
			}
			return result.toString();
		}

		public static void main(String[] args) {
			String uniqueDataString = "Greg Monti"; 
			String checksum = generateChecksum(uniqueDataString);
			System.out.println("Unique Data String: " + uniqueDataString);
			System.out.println("Algorithm Cipher: SHA-256");
			System.out.println("Checksum Hash Value: " + checksum);
		}
	}
	@RequestMapping("/hash")
	public String myHash(){
		String data = "Hello Greg Monti!";

		return "<p>data:"+data;
	}
}
